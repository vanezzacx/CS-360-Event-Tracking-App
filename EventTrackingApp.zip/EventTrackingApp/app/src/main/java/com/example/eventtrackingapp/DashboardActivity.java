package com.example.eventtrackingapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout tableEvents;
    private Button btnAddEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        databaseHelper = new DatabaseHelper(this);
        tableEvents = findViewById(R.id.tableEvents);
        btnAddEvent = findViewById(R.id.buttonAddEvent);

        btnAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddEventActivity.class);
            startActivity(intent);
        });

        loadEvents();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTable();
    }

    private void refreshTable() {
        while (tableEvents.getChildCount() > 1) {
            tableEvents.removeViewAt(1);
        }

        loadEvents();
    }

    private void loadEvents() {
        Cursor cursor = databaseHelper.getAllEvents();

        if (cursor == null || cursor.getCount() == 0) {
            if (cursor != null) {
                cursor.close();
            }
            return;
        }

        while (cursor.moveToNext()) {
            int eventId = cursor.getInt(0);
            String name = cursor.getString(1);
            String date = cursor.getString(2);
            String time = cursor.getString(3);
            String location = cursor.getString(4);

            TableRow row = new TableRow(this);

            TextView eventName = new TextView(this);
            TextView eventDate = new TextView(this);
            TextView eventTime = new TextView(this);
            TextView eventLocation = new TextView(this);

            eventName.setPadding(8, 8, 8, 8);
            eventDate.setPadding(8, 8, 8, 8);
            eventTime.setPadding(8, 8, 8, 8);
            eventLocation.setPadding(8, 8, 8, 8);

            eventName.setText(name);
            eventDate.setText(date);
            eventTime.setText(time);
            eventLocation.setText(location);

            row.addView(eventName);
            row.addView(eventDate);
            row.addView(eventTime);
            row.addView(eventLocation);

            row.setOnLongClickListener(v -> {
                String[] options = {"Edit Event", "Delete Event"};

                new AlertDialog.Builder(DashboardActivity.this)
                        .setTitle("Event Options")
                        .setItems(options, (dialog, which) -> {
                            if (which == 0) {
                                Intent intent = new Intent(DashboardActivity.this, AddEventActivity.class);
                                intent.putExtra("EVENT_ID", eventId);
                                intent.putExtra("EVENT_NAME", name);
                                intent.putExtra("EVENT_DATE", date);
                                intent.putExtra("EVENT_TIME", time);
                                intent.putExtra("EVENT_LOCATION", location);
                                startActivity(intent);
                            } else {
                                confirmDelete(eventId);
                            }
                        })
                        .show();

                return true;
            });

            tableEvents.addView(row);
        }

        cursor.close();
    }

    private void confirmDelete(int eventId) {
        new AlertDialog.Builder(DashboardActivity.this)
                .setTitle("Delete Event")
                .setMessage("Are you sure you want to delete this event?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    boolean deleted = databaseHelper.deleteEvent(eventId);

                    if (deleted) {
                        Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
                        refreshTable();
                    } else {
                        Toast.makeText(this, "Event not deleted", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}