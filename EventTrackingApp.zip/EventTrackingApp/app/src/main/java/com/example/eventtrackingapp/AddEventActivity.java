package com.example.eventtrackingapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    private EditText editEventName;
    private EditText editEventDate;
    private EditText editEventTime;
    private EditText editEventLocation;
    private Button buttonSaveEvent;
    private DatabaseHelper databaseHelper;
    private Button buttonReminder;
    private Button buttonCancel;
    private static final int SMS_PERMISSION_CODE = 100;

    private int eventId = -1;
    private boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventLocation = findViewById(R.id.editEventLocation);
        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);
        buttonReminder = findViewById(R.id.buttonReminder);
        buttonCancel = findViewById(R.id.buttonCancel);

        buttonReminder.setOnClickListener(v -> {

            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);

            } else {
                sendReminder();
            }

        });

        buttonCancel.setOnClickListener(v -> finish());

        databaseHelper = new DatabaseHelper(this);

        checkForEditMode();

        buttonSaveEvent.setOnClickListener(v -> saveEvent());
    }

    private void checkForEditMode() {
        if (getIntent().hasExtra("EVENT_ID")) {
            isEditMode = true;

            eventId = getIntent().getIntExtra("EVENT_ID", -1);
            String name = getIntent().getStringExtra("EVENT_NAME");
            String date = getIntent().getStringExtra("EVENT_DATE");
            String time = getIntent().getStringExtra("EVENT_TIME");
            String location = getIntent().getStringExtra("EVENT_LOCATION");

            editEventName.setText(name);
            editEventDate.setText(date);
            editEventTime.setText(time);
            editEventLocation.setText(location);

            buttonSaveEvent.setText("Update Event");
        }
    }

    private void saveEvent() {
        String name = editEventName.getText().toString().trim();
        String date = editEventDate.getText().toString().trim();
        String time = editEventTime.getText().toString().trim();
        String location = editEventLocation.getText().toString().trim();

        if (name.isEmpty() || date.isEmpty() || time.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please fill in all event fields", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success;

        if (isEditMode) {
            success = databaseHelper.updateEvent(eventId, name, date, time, location);

            if (success) {
                Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Event was not updated", Toast.LENGTH_SHORT).show();
            }

        } else {
            success = databaseHelper.insertEvent(name, date, time, location);

            if (success) {
                Toast.makeText(this, "Event saved", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Event was not saved", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void sendReminder() {

        try {

            SmsManager smsManager = SmsManager.getDefault();

            // Replace with your own phone number while testing
            smsManager.sendTextMessage(
                    "5551234567",
                    null,
                    "Reminder: " + editEventName.getText().toString(),
                    null,
                    null);

            Toast.makeText(this,
                    "Reminder sent!",
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {

            Toast.makeText(this,
                    "Unable to send SMS",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {

        super.onRequestPermissionsResult(requestCode,
                permissions,
                grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                sendReminder();

            } else {

                Toast.makeText(this,
                        "SMS permission denied. The app will continue without reminders.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
