package com.example.eventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database information
    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 1;

    // User table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Event table
    public static final String TABLE_EVENTS = "events";
    public static final String COL_EVENT_ID = "eventId";
    public static final String COL_EVENT_NAME = "eventName";
    public static final String COL_DATE = "eventDate";
    public static final String COL_TIME = "eventTime";
    public static final String COL_LOCATION = "location";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsers =
                "CREATE TABLE " + TABLE_USERS + "(" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        COL_USERNAME + " TEXT UNIQUE," +
                        COL_PASSWORD + " TEXT)";

        String createEvents =
                "CREATE TABLE " + TABLE_EVENTS + "(" +
                        COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        COL_EVENT_NAME + " TEXT," +
                        COL_DATE + " TEXT," +
                        COL_TIME + " TEXT," +
                        COL_LOCATION + " TEXT)";

        db.execSQL(createUsers);
        db.execSQL(createEvents);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // Register a new user
    public boolean insertUser(String username, String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }

    // Check login credentials
    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE username=? AND password=?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;

        cursor.close();

        return exists;
    }

    // Add an event
    public boolean insertEvent(String name, String date, String time, String location) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_EVENT_NAME, name);
        values.put(COL_DATE, date);
        values.put(COL_TIME, time);
        values.put(COL_LOCATION, location);

        long result = db.insert(TABLE_EVENTS, null, values);

        return result != -1;
    }

    // Read all events
    public Cursor getAllEvents() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_EVENTS,
                null
        );
    }

    // Update an event
    public boolean updateEvent(int id, String name, String date,
                               String time, String location) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_EVENT_NAME, name);
        values.put(COL_DATE, date);
        values.put(COL_TIME, time);
        values.put(COL_LOCATION, location);

        int rows = db.update(TABLE_EVENTS,
                values,
                COL_EVENT_ID + "=?",
                new String[]{String.valueOf(id)});

        return rows > 0;
    }

    // Delete an event
    public boolean deleteEvent(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int rows = db.delete(TABLE_EVENTS,
                COL_EVENT_ID + "=?",
                new String[]{String.valueOf(id)});

        return rows > 0;
    }
}